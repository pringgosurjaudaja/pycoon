$(document).ready(function() {
    console.log( "ready!" );
    
    $('.huge.circular.ui.icon.button')
    .popup({
        inline: true
    })
    ;

    // $('#delete-course').click(function() {
    //     $('.ui.modal')
    //     .modal('show')
    //     ;
    // });
});
